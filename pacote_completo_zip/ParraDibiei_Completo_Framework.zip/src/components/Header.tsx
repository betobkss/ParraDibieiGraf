/**
 * ParraDibiei - Header & Navegação Principal
 * Barra superior oficial do framework ParraDibiei - API & Oracle DBA Grafana Studio
 */

import React from 'react';
import {
  Database,
  Bot,
  Flame,
  BookOpen,
  History,
  Activity,
  Download,
  Moon,
  Sun,
  ExternalLink,
} from 'lucide-react';
import { TabType } from '../types/parradibiei';
import { triggerZipDownload, PARRA_DIBIEI_FULL_ZIP_BASE64 } from '../utils/zipData';

interface HeaderProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  lang: 'pt' | 'en';
  setLang: (lang: 'pt' | 'en') => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  totalCasesCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  lang,
  setLang,
  darkMode,
  setDarkMode,
  totalCasesCount,
}) => {
  const t = {
    pt: {
      brand: 'ParraDibiei',
      tag: 'API & Oracle DBA Grafana Studio',
      copilot: 'Copiloto IA (Guiado)',
      grafana: 'Grafana v10 Imbutido',
      playbooks: '43 Playbooks',
      history: 'Histórico Vivo',
      doctor: 'Auditoria (Doctor)',
      downloadZip: 'Baixar Framework (.ZIP)',
    },
    en: {
      brand: 'ParraDibiei',
      tag: 'API & Oracle DBA Grafana Studio',
      copilot: 'AI Copilot (Guided)',
      grafana: 'Embedded Grafana v10',
      playbooks: '43 Playbooks',
      history: 'Live History',
      doctor: 'Audit (Doctor)',
      downloadZip: 'Download Framework (.ZIP)',
    },
  }[lang];

  return (
    <header className="border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/95 backdrop-blur sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Brand & Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => setActiveTab('copilot')}
            className="flex items-center gap-2.5 text-left focus:outline-none group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-indigo-800 text-white flex items-center justify-center shadow-md group-hover:scale-105 transition-all">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-bold tracking-tight text-slate-900 dark:text-white block leading-tight">
                {t.brand}
              </span>
              <span className="text-xs text-indigo-600 dark:text-indigo-400 block leading-none font-semibold">
                {t.tag}
              </span>
            </div>
          </button>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1 xl:gap-2">
          {/* 1. Copiloto IA */}
          <button
            onClick={() => setActiveTab('copilot')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'copilot'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Bot className="w-4 h-4 text-indigo-400" />
            <span>{t.copilot}</span>
          </button>

          {/* 2. Grafana v10 */}
          <button
            onClick={() => setActiveTab('grafana')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'grafana'
                ? 'bg-[#f05a28] text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Flame className="w-4 h-4 text-[#f05a28]" />
            <span>{t.grafana}</span>
          </button>

          {/* 3. Playbooks */}
          <button
            onClick={() => setActiveTab('playbooks')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'playbooks'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <BookOpen className="w-4 h-4 text-indigo-400" />
            <span>{t.playbooks}</span>
          </button>

          {/* 4. Histórico Vivo */}
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <History className="w-4 h-4 text-emerald-400" />
            <span>{t.history}</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 tabular-nums">
              {totalCasesCount}
            </span>
          </button>

          {/* 5. Doctor */}
          <button
            onClick={() => setActiveTab('doctor')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
              activeTab === 'doctor'
                ? 'bg-indigo-600 text-white shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800/60'
            }`}
          >
            <Activity className="w-4 h-4 text-emerald-400" />
            <span>{t.doctor}</span>
          </button>
        </nav>

        {/* Right Action Buttons */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Download Framework Button */}
          {/* Download Framework Button - In-Memory Guaranteed Download */}
          <button
            onClick={() => triggerZipDownload(PARRA_DIBIEI_FULL_ZIP_BASE64, 'ParraDibiei_Completo_Com_Grafana_e_IA.zip')}
            className="hidden sm:inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 rounded-lg shadow-sm transition-all hover:scale-[1.02] whitespace-nowrap active:scale-95"
            title="Download direto do framework completo"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t.downloadZip}</span>
          </button>

          {/* Language Toggle */}
          <button
            onClick={() => setLang(lang === 'pt' ? 'en' : 'pt')}
            className="px-2.5 py-1 text-xs font-semibold rounded-md border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            {lang === 'pt' ? 'PT-BR' : 'EN'}
          </button>

          {/* Dark Mode Toggle */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className="p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            aria-label="Toggle Dark Mode"
          >
            {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="lg:hidden flex overflow-x-auto px-4 py-2 border-t border-slate-100 dark:border-slate-800/60 gap-1.5 text-xs">
        <button
          onClick={() => setActiveTab('copilot')}
          className={`px-3 py-1.5 rounded-md whitespace-nowrap font-medium flex items-center gap-1 ${
            activeTab === 'copilot'
              ? 'bg-indigo-600 text-white'
              : 'text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800'
          }`}
        >
          <Bot className="w-3.5 h-3.5" />
          <span>Copiloto</span>
        </button>

        <button
          onClick={() => setActiveTab('grafana')}
          className={`px-3 py-1.5 rounded-md whitespace-nowrap font-medium flex items-center gap-1 ${
            activeTab === 'grafana'
              ? 'bg-[#f05a28] text-white'
              : 'text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800'
          }`}
        >
          <Flame className="w-3.5 h-3.5" />
          <span>Grafana</span>
        </button>

        <button
          onClick={() => setActiveTab('playbooks')}
          className={`px-3 py-1.5 rounded-md whitespace-nowrap font-medium flex items-center gap-1 ${
            activeTab === 'playbooks'
              ? 'bg-indigo-600 text-white'
              : 'text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          <span>Playbooks</span>
        </button>

        <button
          onClick={() => setActiveTab('history')}
          className={`px-3 py-1.5 rounded-md whitespace-nowrap font-medium flex items-center gap-1 ${
            activeTab === 'history'
              ? 'bg-emerald-600 text-white'
              : 'text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          <span>Histórico ({totalCasesCount})</span>
        </button>

        <button
          onClick={() => setActiveTab('doctor')}
          className={`px-3 py-1.5 rounded-md whitespace-nowrap font-medium flex items-center gap-1 ${
            activeTab === 'doctor'
              ? 'bg-indigo-600 text-white'
              : 'text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>Doctor</span>
        </button>
      </div>
    </header>
  );
};
