/**
 * ParraDibiei - API & Oracle DBA Grafana Studio
 * Aplicação Central e Ponto de Entrada do Framework
 * 
 * Estrutura 100% modular, sem dependências desnecessárias, com código limpo e comentado.
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { AiCopilotStudio } from './components/AiCopilotStudio';
import { GrafanaSuite } from './components/GrafanaSuite';
import { PlaybooksExplorer } from './components/PlaybooksExplorer';
import { IncidentHistoryViewer } from './components/IncidentHistoryViewer';
import { DoctorViewer } from './components/DoctorViewer';

import { TabType, HistoryData, IncidentCase } from './types/parradibiei';
import { INITIAL_HISTORY, PLAYBOOKS_CATALOG } from './data/parradibieiData';
import { triggerZipDownload } from './utils/zipData';
import { Download } from 'lucide-react';

export default function App() {
  // Estado da aba ativa (Padrão: Copiloto IA para troubleshooting imediato)
  const [activeTab, setActiveTab] = useState<TabType>('copilot');

  // Idioma (Português / Inglês)
  const [lang, setLang] = useState<'pt' | 'en'>('pt');

  // Tema Escuro (Padrão para DBAs e Grafana)
  const [darkMode, setDarkMode] = useState<boolean>(true);

  // Histórico vivo de incidentes (sincronizado em memória com fallback no LocalStorage)
  const [historyData, setHistoryData] = useState<HistoryData>(() => {
    try {
      const saved = localStorage.getItem('parradibiei_history_data');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.warn('Erro ao carregar histórico do localStorage:', e);
    }
    return INITIAL_HISTORY;
  });

  // Sincroniza classe 'dark' no elemento raiz HTML
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Callback chamado pelo Copiloto IA ao concluir e registrar um incidente no histórico
  const handleCaseResolved = (newCase: IncidentCase) => {
    setHistoryData((prev) => {
      const updatedCasos = [newCase, ...prev.casos];
      const updated: HistoryData = {
        ...prev,
        casos_totais: updatedCasos.length,
        atualizado_em: new Date().toISOString(),
        casos: updatedCasos,
      };
      try {
        localStorage.setItem('parradibiei_history_data', JSON.stringify(updated));
      } catch (e) {
        console.warn('Erro ao salvar no localStorage:', e);
      }
      return updated;
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      {/* 1. Barra Superior Oficial com Navegação e Botão de Download */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        lang={lang}
        setLang={setLang}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        totalCasesCount={historyData.casos.length}
      />

      {/* 2. Conteúdo Principal das Abas */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {/* Aba 1: Copiloto IA de Troubleshooting Guiado */}
        {activeTab === 'copilot' && (
          <AiCopilotStudio
            lang={lang}
            onCaseResolved={handleCaseResolved}
            onNavigateToHistory={() => setActiveTab('history')}
          />
        )}

        {/* Aba 2: Observabilidade Grafana v10 & Prometheus Imbutida */}
        {activeTab === 'grafana' && <GrafanaSuite lang={lang} />}

        {/* Aba 3: Catálogo de 43 Playbooks Homologados com Gestão de Risco */}
        {activeTab === 'playbooks' && (
          <PlaybooksExplorer
            playbooks={PLAYBOOKS_CATALOG}
            lang={lang}
            onSelectPlaybookInCopilot={() => setActiveTab('copilot')}
          />
        )}

        {/* Aba 4: Histórico Vivo de Incidentes e Auditoria (historico.json) */}
        {activeTab === 'history' && (
          <IncidentHistoryViewer historyData={historyData} lang={lang} />
        )}

        {/* Aba 5: Diagnóstico do Ambiente e Homologação (troubleshoot.doctor) */}
        {activeTab === 'doctor' && <DoctorViewer lang={lang} />}
      </main>

      {/* 3. Rodapé Oficial */}
      <footer className="border-t border-slate-200 dark:border-slate-900 py-6 text-center text-xs text-slate-500 dark:text-slate-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              ParraDibiei - API & Oracle DBA Grafana Studio
            </span>
            <span>·</span>
            <span>Read-Only Inviolável</span>
            <span>·</span>
            <span>Homologado RAC & Exadata</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => triggerZipDownload()}
              className="text-emerald-500 hover:text-emerald-400 font-semibold transition-colors cursor-pointer flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              {lang === 'pt' ? 'Baixar Pacote Completo (.ZIP)' : 'Download Full Package (.ZIP)'}
            </button>
            <span>·</span>
            <button
              onClick={() => setActiveTab('doctor')}
              className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
            >
              {lang === 'pt' ? 'Diagnóstico do Doctor' : 'Doctor Diagnostics'}
            </button>
            <span>·</span>
            <button
              onClick={() => setActiveTab('history')}
              className="hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors"
            >
              {lang === 'pt' ? 'Histórico do Projeto' : 'Project History'}
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
