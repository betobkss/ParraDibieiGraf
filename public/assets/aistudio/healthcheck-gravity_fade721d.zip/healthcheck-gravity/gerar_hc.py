import base64, json, os, sys
from email.message import EmailMessage
from email.utils import make_msgid
B = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.getcwd()
cfg = json.load(open(f'{B}/dados.json', encoding='utf-8'))
secoes = cfg['secoes']
def corpo(src):
    h = ['<div style="font-family:Calibri,Arial,sans-serif;font-size:11pt;color:#000">',
         '<p style="font-size:14pt;margin:0"><b>Health Check - Banco de dados</b></p>',
         f'<p style="font-size:12pt;margin:4px 0 14px 0"><b>{cfg["referencia"]}</b></p>']
    for s in secoes:
        h.append(f'<p style="font-size:12pt;margin:16px 0 6px 0"><b>{s["icone"]} {s["titulo"]}</b></p>')
        for t in s.get('texto', []):
            h.append(f'<p style="margin:2px 0">{t}</p>')
        if s.get('tabela'):
            h.append('<table style="border-collapse:collapse;margin:6px 0;font-size:10.5pt">')
            for i, row in enumerate(s['tabela']):
                tag = 'th' if i == 0 else 'td'
                bg = 'background:#d9e2f3;' if i == 0 else ''
                h.append('<tr>' + ''.join(f'<{tag} style="border:1px solid #8ea9db;padding:3px 10px;{bg}text-align:left">{c}</{tag}>' for c in row) + '</tr>')
            h.append('</table>')
        if s.get('codigo'):
            h.append(f'<pre style="font-family:Consolas,monospace;font-size:9.5pt;background:#f2f2f2;padding:6px;margin:4px 0;white-space:pre-wrap">{s["codigo"]}</pre>')
        for img in s.get('imagens', []):
            h.append(f'<p style="margin:4px 0"><img src="{src(img)}" style="max-width:900px" alt="{img}"></p>')
    h.append(f'<p style="margin-top:18px">{cfg["assinatura"]}</p></div>')
    return '\n'.join(h)
imgs = [i for s in secoes for i in s.get('imagens', [])]
html_prev = corpo(lambda n: 'data:image/png;base64,' + base64.b64encode(open(f'{B}/img/{n}', 'rb').read()).decode())
open(f'{B}/{cfg["arquivo"]}.html', 'w', encoding='utf-8').write(f'<!doctype html><html><head><meta charset="utf-8"><title>{cfg["assunto"]}</title></head><body>{html_prev}</body></html>')
cids = {n: make_msgid(domain='healthcheck.local')[1:-1] for n in imgs}
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email import policy
from email.header import Header
m = MIMEMultipart('related')
m['Subject'] = Header(cfg['assunto'], 'utf-8').encode()
m['To'] = cfg.get('para', '')
if cfg.get('cc'):
    m['Cc'] = cfg['cc']
m['X-Unsent'] = '1'
alt = MIMEMultipart('alternative')
alt.attach(MIMEText('Health Check - Banco de dados (versao HTML).', 'plain', 'utf-8'))
alt.attach(MIMEText('<html><head><meta charset="utf-8"></head><body>' + corpo(lambda n: "cid:" + cids[n]) + '</body></html>', 'html', 'utf-8'))
m.attach(alt)
for n in dict.fromkeys(imgs):
    im = MIMEImage(open(f'{B}/img/{n}', 'rb').read(), 'png')
    im.add_header('Content-ID', f'<{cids[n]}>')
    im.add_header('Content-Disposition', 'inline', filename=n)
    m.attach(im)
open(f'{B}/{cfg["arquivo"]}.eml', 'wb').write(m.as_bytes(policy=policy.SMTP))
print('ok', len(imgs), 'imagens')
