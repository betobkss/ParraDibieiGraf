---
name: healthcheck-gravity
description: Monta o Health Check gerencial do banco Gravity (.eml pronto para envio + .html de conferencia) a partir dos prints do Dynatrace "last 2 hours" e das saidas de terminal (bloqueios > 5 s e lag do Data Guard). Usar quando o usuario pedir "Health Check", "relatorio HC", "monta o email do HC" ou mandar os prints do painel Gravity.
---

# Health Check gerencial - Gravity

## Fluxo (o usuario manda tudo, o agente faz o resto, sem perguntar)
1. O usuario manda TODOS os prints do Dynatrace (dashboards "Plataforma Gravity X10 - CPU % Used" e
   "ALMA Gravity - Oracle Database Technical Overview - GRVT FULL", filtro "Last 2 hours") e cola as saidas de terminal
   (ver "Comandos de terminal").
2. O agente RECORTA cada painel em UMA imagem (PIL `crop`), escolhe SO os 13 da lista abaixo e na ordem.
   Nunca mandar painel composto. Conferir os recortes numa montagem antes de gerar (`view_image`).
3. O agente escreve os textos SO da janela dos prints (hora do HC - 2 h). Nunca reaproveitar texto de outro horario.
4. Preenche `dados.json`, roda `python3 gerar_hc.py <pasta>` (espera `ok 13 imagens`), renderiza o HTML
   (`google-chrome --headless --screenshot`) para conferir e entrega o `.eml` + `.html` como anexo.
   Para e Cc em branco salvo se o usuario informar.

## Prints - SO estes, nesta ordem, UM painel por imagem
| # | arquivo | painel |
|---|---|---|
| 1 | sum_host_proc.png | SUMMARY: Host Availability + Listener Status + DB Processes Status (um recorte so) |
| 2 | sess_db0p.png | oecb1ret_db0p - Active/blocked sessions |
| 3 | sess_opac.png | oecb1par_opac - Active/blocked sessions |
| 4 | cpu_worka.png | CPU_GRVT_BRASIL_WORKA |
| 5 | cpu_workb.png | CPU_GRVT_BRASIL_WORKB |
| 6 | cpu_golden_dcs.png | CPU_GRVT_BRASIL_GOLDEN DCS |
| 7 | cpu_golden_dcn.png | CPU_GRVT_BRASIL_GOLDEN DCN |
| 8 | cpu_pac_dcs.png | CPU_GRVT_BRASIL_PAC DCS |
| 9 | cpu_pac_dcn.png | CPU_GRVT_BRASIL_PAC DCN |
| 10 | diskgroup.png | Disk Group Storage Usage |
| 11 | filesystem.png | Filesystem /u01 /u02 Usage % |
| 12 | tablespace.png | Tablespace Usage |
| 13 | lag_db.png | Lag DB (Golden) |

NAO incluir: DB Time, CPU/Memory/FRA/PGA do summary, IO Latency, FlashCache, DataGuard LAG, nem prints de terminal.
O lag do Data Guard vai em TABELA e a contagem de bloqueios vai em TEXTO. O valor do painel DataGuard LAG (Golden)
pode ser citado em texto na secao da Golden.
Se a ordem dos prints recebidos vier diferente, identifique pelo titulo do painel.
Dica de recorte: se o print foi exibido reduzido, aplique o fator `largura_real / largura_exibida` nas coordenadas.

## Secoes do e-mail (ver dados.exemplo_gravity.json)
1. Disponibilidade (Host, Listener e Processos do banco) - img 1
2. Atividade de bloqueios - img 2-3 (faixa de ativas, picos com hora, bloqueadas)
3. Consumo de CPU WorkA, PAC e Golden - img 4-9 (faixa e picos com hora por cluster)
4. Consumo de DG e filesystem e tablespace - img 10-12 (% livre dos diskgroups, % uso /u01)
5. Lag no Data Guard (em minutos) - tabela transport/apply lag + status do Broker
6. Observacao - lag da copia Golden - img 13
7. Quantidade de bloqueios com mais de 5 segundos - texto com o valor e a hora
Icone: ✅ normal, ⚠️ atencao (ex.: Broker WARNING / ORA-16853), ❌ indisponibilidade.

## Regras de interpretacao (ambiente PROD critico; nada de mudanca no banco)
- Topologia: WORKA (c3cnbrapro01, 8 nos RAC, oecbn1ret) e WORKB (c3cnbrapro02) se alternam como primary
  toda semana (flip-flop da engenharia). Isso e NORMAL, nao e incidente. Confirme o primary com `PRIMARY | READ WRITE`.
- DR oficial do WORKA = oecbs1ret (c3csbrapro01, physical standby, Broker "WORKA").
- Golden (c3csbrapro03) NAO esta no Broker e nao e DR oficial confirmado: lag dela entra como observacao, nunca como falha do DR.
- Bloqueios > 5 s de GV$SESSION sao contagem INSTANTANEA: 1 sessao pontual nao indica acumulo. Nao misturar com o CSV historico de bloqueios (ASH).
- Broker WARNING / ORA-16853 = apply lag acima do limite configurado: marcar ⚠️ "seguir acompanhando"; nao inventar causa.
  Se normalizar no HC seguinte, escrever que normalizou, sem atribuir causa.
- Diferenciar "compativel com" de "causa comprovada". Nao afirmar o que nao foi medido.

## Comandos de terminal (o usuario roda e cola a saida)
```bash
# 1) PRIMARY da semana (no 1, como oracle) - identidade + bloqueios > 5 s (contagem instantanea)
. ~/oecb1ret.env; unset ORACLE_PDB_SID; echo "HC_HOST=$(hostname)"; sqlplus -s / as sysdba <<'SQL'
set heading off feedback off pages 0 lines 200
select 'HC_DATA='||to_char(sysdate,'DD/MM/YYYY HH24:MI') from dual;
select 'HC_DB='||db_unique_name||'|'||database_role||'|'||open_mode from v$database;
select 'HC_BLOQ5S='||count(*) from gv$session where blocking_session is not null and wait_class='Application' and seconds_in_wait>5;
SQL

# 2) PRIMARY - lag pelo Broker
dgmgrl / "show configuration lag"

# 3) STANDBY (no 1, como oracle) - papel e lag
. ~/oecb1ret.env; unset ORACLE_PDB_SID; hostname; sqlplus -s / as sysdba <<'SQL'
set lines 200 pages 100
col value for a20
select db_unique_name, database_role, open_mode from v$database;
select name, value, time_computed from v$dataguard_stats where name in ('transport lag','apply lag');
SQL

# Qual e o primary (flip-flop semanal WORKA/WORKB): tem que retornar PRIMARY | READ WRITE
. ~/oecb1ret.env; sqlplus -s / as sysdba <<< "select database_role||' | '||open_mode from v\$database;"
```

## dados.json (estrutura; exemplo real em dados.exemplo_gravity.json)
Campos: arquivo (nome base do .eml/.html), assunto, para, cc, referencia, assinatura, secoes[] com
icone, titulo, texto[] (HTML permitido), tabela (lista de linhas, 1a = cabecalho), imagens[] (arquivos em <pasta>/img/).
```json
{
 "arquivo": "HealthCheck_<AAAA-MM-DD>_<HH>h",
 "assunto": "Health Check - Banco de dados - <SISTEMA> - <DD/MM/AAAA> - <HH>h",
 "para": "",
 "cc": "",
 "referencia": "<DD/MM/AAAA> - <HH>h00",
 "assinatura": "Atenciosamente,<br><Nome><br><Equipe>",
 "secoes": [
  {
   "icone": "✅",
   "titulo": "Disponibilidade (Host, Listener e Processos do banco)",
   "texto": [
    "Janela analisada: <HH>h às <HH>h (painéis \"last 2 hours\"). Hosts disponíveis, listeners ativos e <N> processos de banco OK."
   ],
   "imagens": [
    "01_summary_host_listener_proc.png"
   ]
  },
  {
   "icone": "✅",
   "titulo": "Atividade de bloqueios",
   "texto": [
    "<PDB1>: <faixa> sessões ativas, picos <hora>. Bloqueadas: <...>.",
    "<PDB2>: <...>."
   ],
   "imagens": [
    "02_sessoes_pdb1.png",
    "03_sessoes_pdb2.png"
   ]
  },
  {
   "icone": "✅",
   "titulo": "Consumo de CPU por cluster",
   "texto": [
    "<SITE_A> (produção): <faixa>. <SITE_B> (site inativo): <faixa>.",
    "<COPIA> DCS/DCN: <faixa>. <PAC> DCS/DCN: <faixa>."
   ],
   "imagens": [
    "04_cpu_site_a.png",
    "05_cpu_site_b.png",
    "06_cpu_copia_dcs.png",
    "07_cpu_copia_dcn.png",
    "08_cpu_pac_dcs.png",
    "09_cpu_pac_dcn.png"
   ]
  },
  {
   "icone": "✅",
   "titulo": "Consumo de DG e filesystem e tablespace",
   "texto": [
    "Diskgroups com <x>% a <y>% livres; filesystem /u01 entre <x>% e <y>%; tablespaces sem alerta."
   ],
   "imagens": [
    "10_diskgroup.png",
    "11_filesystem.png",
    "12_tablespace.png"
   ]
  },
  {
   "icone": "✅",
   "titulo": "Lag no Data Guard (em minutos)",
   "texto": [
    "<primary> &rarr; <standby>, <protection mode>. Coleta das <hh:mm> (Broker + V$DATAGUARD_STATS). Transport lag: <x> s. Apply lag: <y> s. Broker: <SUCCESS/WARNING>."
   ],
   "tabela": [
    [
     "Métrica",
     "Valor",
     "Minutos"
    ],
    [
     "transport lag",
     "<x> s",
     "<m>"
    ],
    [
     "apply lag",
     "<y> s",
     "<m>"
    ]
   ]
  },
  {
   "icone": "✅",
   "titulo": "Observação - lag da cópia <COPIA>",
   "texto": [
    "Painel Lag DB: <...>. Cópia fora do Broker: não tratar como DR oficial sem evidência."
   ],
   "imagens": [
    "13_lag_db_copia.png"
   ]
  },
  {
   "icone": "✅",
   "titulo": "Quantidade de bloqueios com mais de 5 segundos",
   "texto": [
    "<N> sessões bloqueadas > 5 s (wait class Application) no primary às <hh:mm> (contagem instantânea de GV$SESSION)."
   ]
  }
 ]
}
```

## gerar_hc.py (copiar para a pasta de trabalho; uso: python3 gerar_hc.py <pasta>)
```python
import base64, json, os, sys
from email.message import EmailMessage
from email.utils import make_msgid
B = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else os.getcwd()
cfg = json.load(open(f'{B}/dados.json', encoding='utf-8'))
secoes = cfg['secoes']
def corpo(src):
    h = ['<div style="font-family:Calibri,Arial,sans-serif;font-size:11pt;color:#000">',
         '<p style="font-size:14pt;margin:0"><b>Health Check - Banco de dados</b></p>',
         f'<p style="font-size:12pt;margin:4px 0 14px 0"><b>{cfg["referencia"]}</b></p>']
    for s in secoes:
        h.append(f'<p style="font-size:12pt;margin:16px 0 6px 0"><b>{s["icone"]} {s["titulo"]}</b></p>')
        for t in s.get('texto', []):
            h.append(f'<p style="margin:2px 0">{t}</p>')
        if s.get('tabela'):
            h.append('<table style="border-collapse:collapse;margin:6px 0;font-size:10.5pt">')
            for i, row in enumerate(s['tabela']):
                tag = 'th' if i == 0 else 'td'
                bg = 'background:#d9e2f3;' if i == 0 else ''
                h.append('<tr>' + ''.join(f'<{tag} style="border:1px solid #8ea9db;padding:3px 10px;{bg}text-align:left">{c}</{tag}>' for c in row) + '</tr>')
            h.append('</table>')
        if s.get('codigo'):
            h.append(f'<pre style="font-family:Consolas,monospace;font-size:9.5pt;background:#f2f2f2;padding:6px;margin:4px 0;white-space:pre-wrap">{s["codigo"]}</pre>')
        for img in s.get('imagens', []):
            h.append(f'<p style="margin:4px 0"><img src="{src(img)}" style="max-width:900px" alt="{img}"></p>')
    h.append(f'<p style="margin-top:18px">{cfg["assinatura"]}</p></div>')
    return '\n'.join(h)
imgs = [i for s in secoes for i in s.get('imagens', [])]
html_prev = corpo(lambda n: 'data:image/png;base64,' + base64.b64encode(open(f'{B}/img/{n}', 'rb').read()).decode())
open(f'{B}/{cfg["arquivo"]}.html', 'w', encoding='utf-8').write(f'<!doctype html><html><head><meta charset="utf-8"><title>{cfg["assunto"]}</title></head><body>{html_prev}</body></html>')
cids = {n: make_msgid(domain='healthcheck.local')[1:-1] for n in imgs}
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.image import MIMEImage
from email import policy
from email.header import Header
m = MIMEMultipart('related')
m['Subject'] = Header(cfg['assunto'], 'utf-8').encode()
m['To'] = cfg.get('para', '')
if cfg.get('cc'):
    m['Cc'] = cfg['cc']
m['X-Unsent'] = '1'
alt = MIMEMultipart('alternative')
alt.attach(MIMEText('Health Check - Banco de dados (versao HTML).', 'plain', 'utf-8'))
alt.attach(MIMEText('<html><head><meta charset="utf-8"></head><body>' + corpo(lambda n: "cid:" + cids[n]) + '</body></html>', 'html', 'utf-8'))
m.attach(alt)
for n in dict.fromkeys(imgs):
    im = MIMEImage(open(f'{B}/img/{n}', 'rb').read(), 'png')
    im.add_header('Content-ID', f'<{cids[n]}>')
    im.add_header('Content-Disposition', 'inline', filename=n)
    m.attach(im)
open(f'{B}/{cfg["arquivo"]}.eml', 'wb').write(m.as_bytes(policy=policy.SMTP))
print('ok', len(imgs), 'imagens')
```
